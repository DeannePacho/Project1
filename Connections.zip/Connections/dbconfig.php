<?php

	$DB_HOST = 'localhost';
	$DB_USER = 'root';
	$DB_NAME = 'iexplore';
	$DB_PASS = '';
	
	try{ 
	$DB_con = new PDO("mysql:host={$DB_HOST};dbname={$DB_NAME}",$DB_USER,$DB_PASS);
	$DB_con->setATTRIBUTE(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	}catch 
	(PDOException $e){
		echo $e->getMessage();
		
	}
	
	$db_conn = mysqli_connect('localhost', 'root', '', 'iexplore');

        if(mysqli_connect_errno()){
            echo "1: Connection Failed!"; // error code # 1 connection failed 
            exit();
    }
	

	
?>
<?php 

	$conn = mysqli_connect('localhost', 'root', '', 'iexplore');

    if(mysqli_connect_errno())
    {
        echo "1: connection failed"; //error code #1 = connection failed
        exit();
    }



?>

