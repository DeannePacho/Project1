<?php
include_once 'Ajax/dbconfig.php';	
session_start();

	if(!isset($_SESSION['admin_session']))
	{
		header("Location: index.php");
	}

	$stmt = $db_con->prepare("SELECT * FROM admin WHERE admin_id=:uid");
	$stmt->execute(array(":uid"=>$_SESSION['admin_session']));
	$row=$stmt->fetch(PDO::FETCH_ASSOC);
	
?>

<!DOCTYPE html>
<html>
<head>
	<?php include('include/head.php'); ?>
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/media/css/jquery.dataTables.css">
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/media/css/responsive.dataTables.css">
</head>
<body>
	<?php include('include/header.php'); ?>
	<?php include('include/sidebar.php'); ?>
	<div class="main-container">
		<div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">

      <?php include("manage_statistics.php"); ?>

			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Feedbacks Reports</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Reports</a></li>
									<li class="breadcrumb-item active" aria-current="page">Feedback Information</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>
				
				
				
			<!--Modal View Message Start-->
				<!-- Large modal -->
				<div class="col-md-4 col-sm-12">
					<div class="modal fade bs-example-modal-lg" id="viewMemberModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
						<div class="modal-dialog modal-lg modal-dialog-centered">
							<div class="modal-content">
								<div class="modal-header">
									<h4 class="modal-title" id="myLargeModalLabel"><i class="fa fa-envelope"></i> View Message</h4>
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
								</div>
								<div class="modal-body">
							   <div class="col-xl-12 col-lg-8 col-md-8 col-sm-12 mb-30">
									<div class="bg-white border-radius-4 box-shadow height-100-p">
										<div class="profile-tab height-100-p">
											<div class="tab height-100-p">
												<div class="tab-content">
													<!-- Information Tab start -->
													<div class="tab-pane fade show active" id="timeline" role="tabpanel">
														<div class="notification-list mx-h-450 customscroll">
															<div class="pd-20">
																<div class="profile-timeline">
																	<div class="timeline-month">
																		<h5>Message:</h5>
																	</div>
																	<div class="profile-timeline-list">
																		<ul>
																			<li>
																				<textarea class="form-control" name="viewFirstname" id="viewFirstname" readonly></textarea>
																			</li>
																			
																		</ul>
																	</div>
																</div>
															</div>
														</div>
													</div>
													<!-- Information Tab End -->
												</div>
											 </div>
										 </div>
									 </div>
							 	 </div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--Modal View Message End-->
				
				
				
				<!-- Export Datatable start -->
				<div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h5 class="text-blue">Feedback Reports</h5>
						</div>
					</div>
					<div class="row">
						<table class="stripe hover multiple-select-row data-table-export nowrap" id="manageFeedbacksreportTable">
							<thead>
								<tr>
									<th class="table-plus datatable-nosort">No.</th>
									<th class="table-plus datatable-nosort">Date</th>
									<th>Fullname</th>
									<th>Status</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>

							</tbody>
						</table>
					</div>
				</div>
				<!-- Export Datatable End -->
			</div>
			<?php include('include/footer.php'); ?>
		</div>
	</div>
	<?php include('include/script.php'); ?>
	<script src="src/plugins/datatables/media/js/jquery.dataTables.min.js"></script>
	<script src="src/plugins/datatables/media/js/dataTables.bootstrap4.js"></script>
	<script src="src/plugins/datatables/media/js/dataTables.responsive.js"></script>
	<script src="src/plugins/datatables/media/js/responsive.bootstrap4.js"></script>
	<!-- buttons for Export datatable -->
	<script src="src/plugins/datatables/media/js/button/dataTables.buttons.js"></script>
	<script src="src/plugins/datatables/media/js/button/buttons.bootstrap4.js"></script>
	<script src="src/plugins/datatables/media/js/button/buttons.print.js"></script>
	<script src="src/plugins/datatables/media/js/button/buttons.html5.js"></script>
	<script src="src/plugins/datatables/media/js/button/buttons.flash.js"></script>
	<script src="src/plugins/datatables/media/js/button/pdfmake.min.js"></script>
	<script src="src/plugins/datatables/media/js/button/vfs_fonts.js"></script>

	<script type="text/javascript" src="include/feedbacks_report/custom/js/index.js"></script>

</body>
</html>
