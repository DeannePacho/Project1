<?php
if(isset($_SESSION['admin_session']) != "")
{
	header("Location: manage_dashboard.php");
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>i-Explore SFC</title>
	<?php include "include/head.php"; ?>
</head>
<body>
    <div class="form-signin login-wrap customscroll d-flex align-items-center flex-wrap justify-content-center pd-20">
		<div class="login-box bg-white box-shadow pd-30 border-radius-5">
			<img src="vendors/images/login-img.png" alt="login" class="login-img">
			<h2 class="text-center mb-30">Admin Login</h2>
			<form method="POST" id="login-form">
				<p id="error"></p>
				<div class="input-group custom input-group-lg">
					<input type="text" name="username" id="username" class="form-control" placeholder="Username" autocomplete="off">
					<div class="input-group-append custom">
						<span class="input-group-text"><i class="fa fa-user" aria-hidden="true"></i></span>
					</div>
				</div>
				<div class="input-group custom input-group-lg">
					<input type="password" name="password" id="password" class="form-control" placeholder="Password" autocomplete="off">
					<div class="input-group-append custom">
						<span class="input-group-text"><i class="fa fa-key" aria-hidden="true"></i></span>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6">
						<div class="input-group">
							<button type="submit" name="login" id="login" class="btn btn-outline-primary btn-lg btn-block">Sign In <button/>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="forgot-password padding-top-10"><a href="forgot-password.php">Forgot Password</a></div>
					</div>
				</div>
			</form>
		</div>
    </div>
		<script type="text/javascript" src="src/scripts/jquery-1.11.3-jquery.min.js"></script>
		<script type="text/javascript" src="src/scripts/validation.min.js"></script>
		<script type="text/javascript" src="include/login/script.js"></script>

</body>
</html>
