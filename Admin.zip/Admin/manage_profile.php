
<?php
session_start();

if(!isset($_SESSION['admin_session']))
{
	header("Location: index.php");
}

include_once '../Connections/dbconfig.php';

$stmt = $DB_con->prepare("SELECT * FROM admin WHERE admin_id=:uid");
$stmt->execute(array(":uid"=>$_SESSION['admin_session']));
$row=$stmt->fetch(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>
<head>
	<?php include('include/head.php'); ?>
	<link rel="stylesheet" type="text/css" href="src/plugins/cropperjs/dist/cropper.css">
</head>
<body>
	<?php include('include/header.php'); ?>
	<?php include('include/sidebar.php'); ?>
	<div class="main-container">
		<div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-12 col-sm-12">
							<div class="title">
								<h4>Profile</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Profile</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xl-3 col-lg-4 col-md-4 col-sm-12 mb-30">
						<div class="pd-20 bg-white border-radius-4 box-shadow">
							<div class="profile-photo">
								<?php
									$userId = 1;

									//Get user data from database
									$result = $db_conn->query("SELECT * FROM admin WHERE admin_id = $userId");
									$row = $result->fetch_assoc();

									//User profile photo
									$userPicture = !empty($row['photo'])?$row['photo']:'no-image.png';
									$userPictureURL = 'vendors/avatar/'.$userPicture;
								?>
							
								
								
								<div class="overlay uploadProcess" style="display: none;">
									<div class="overlay-content"><img src="vendors/images/loading.gif"/></div>
								</div>
								
								<!-- Hidden upload form -->
								<form method="post" action="upload.php" enctype="multipart/form-data" id="picUploadForm" target="uploadTarget">
									<input type="file" name="photo" id="fileInput"  style="display:none"/>
								</form><br>
								
								<iframe id="uploadTarget" name="uploadTarget" src="#" style="width:0;height:0;border:0px solid #fff;"></iframe>
								 <a class="editLink edit-avatar" href="javascript:void(0);"><i class="fa fa-pencil"></i></a>
															
								
								 <img src="<?php echo $userPictureURL; ?>" id="imagePreview" alt=""  class="avatar-photo">

							</div><br><br>
							<h5 class="text-center"><?php echo $row['firstname'].'&nbsp;&nbsp;'.$row['lastname']?></h5>
							<div class="profile-info">
								<h5 class="mb-20 weight-500">Contact Information</h5>
								<ul>
									<li>
										<span>Email Address:</span>
										<?php echo $row['email_address'] ?>
									</li>
									<li>
										<span>Phone Number:</span>
										<?php echo $row['contact_number'] ?>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-xl-9 col-lg-8 col-md-8 col-sm-12 mb-30">
						<div class="bg-white border-radius-4 box-shadow height-100-p">
							<div class="profile-tab height-100-p">
								<div class="tab height-100-p">
									<ul class="nav nav-tabs customtab" role="tablist">

										<li class="nav-item">
											<a class="nav-link" data-toggle="tab" href="#setting" role="tab">Settings</a>
										</li>
									</ul>
									<div class="tab-content">		
										
										<!-- Setting Tab start -->
										<div class="tab-pane fade show active" id="setting" role="tabpanel">
											<div class="profile-setting">
												<form>
													<ul class="profile-edit-list row">
														<li class="weight-500 col-md-6">
															<h4 class="text-blue mb-20">Edit Your Personal Setting</h4>
															<div class="form-group">
																<label>Username</label>
																<input class="form-control form-control-lg" type="text" name="username" id="username">
															</div>
															<div class="form-group">
																<label>Firstname</label>
																<input class="form-control form-control-lg" type="text" name="firstname" id="firstname">
															</div>
															<div class="form-group">
																<label>Lastname</label>
																<input class="form-control form-control-lg" type="text" name="lastname" id="lastname">
															</div>
															<div class="form-group">
																<label>Email Address</label>
																<input class="form-control form-control-lg" type="email" >
															</div>
															<div class="form-group">
																<label>Contact Number</label>
																<input class="form-control form-control-lg" type="email" >
															</div>

															<div class="form-group mb-0">
																<input type="submit" class="btn btn-primary" value="Update Information">
															</div>
														</li>
														<!--<li class="weight-500 col-md-6">
															<h4 class="text-blue mb-20">Edit Social Media links</h4>
															<div class="form-group">
																<label>Facebook URL:</label>
																<input class="form-control form-control-lg" type="text" placeholder="Paste your link here">
															</div>
															<div class="form-group">
																<label>Twitter URL:</label>
																<input class="form-control form-control-lg" type="text" placeholder="Paste your link here">
															</div>
															<div class="form-group">
																<label>Linkedin URL:</label>
																<input class="form-control form-control-lg" type="text" placeholder="Paste your link here">
															</div>
															<div class="form-group">
																<label>Instagram URL:</label>
																<input class="form-control form-control-lg" type="text" placeholder="Paste your link here">
															</div>
															<div class="form-group">
																<label>Dribbble URL:</label>
																<input class="form-control form-control-lg" type="text" placeholder="Paste your link here">
															</div>
															<div class="form-group">
																<label>Dropbox URL:</label>
																<input class="form-control form-control-lg" type="text" placeholder="Paste your link here">
															</div>
															<div class="form-group">
																<label>Google-plus URL:</label>
																<input class="form-control form-control-lg" type="text" placeholder="Paste your link here">
															</div>
															<div class="form-group">
																<label>Pinterest URL:</label>
																<input class="form-control form-control-lg" type="text" placeholder="Paste your link here">
															</div>
															<div class="form-group">
																<label>Skype URL:</label>
																<input class="form-control form-control-lg" type="text" placeholder="Paste your link here">
															</div>
															<div class="form-group">
																<label>Vine URL:</label>
																<input class="form-control form-control-lg" type="text" placeholder="Paste your link here">
															</div>
															<div class="form-group mb-0">
																<input type="submit" class="btn btn-primary" value="Save & Update">
															</div>
														</li> -->
													</ul>
												</form>
											</div>
										</div>
										<!-- Setting Tab End -->
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php include('include/script.php'); ?>
	<script src="src/plugins/cropperjs/dist/cropper.js"></script>
	<script>
		window.addEventListener('DOMContentLoaded', function () {
			var image = document.getElementById('image');
			var cropBoxData;
			var canvasData;
			var cropper;

			$('#modal').on('shown.bs.modal', function () {
				cropper = new Cropper(image, {
					autoCropArea: 0.5,
					dragMode: 'move',
					aspectRatio: 3 / 3,
					restore: false,
					guides: false,
					center: false,
					highlight: false,
					cropBoxMovable: false,
					cropBoxResizable: false,
					toggleDragModeOnDblclick: false,
					ready: function () {
						cropper.setCropBoxData(cropBoxData).setCanvasData(canvasData);
					}
				});
			}).on('hidden.bs.modal', function () {
				cropBoxData = cropper.getCropBoxData();
				canvasData = cropper.getCanvasData();
				cropper.destroy();
			});
		});
	</script>
	
	
	<script type="text/javascript">
		$(document).ready(function () {
			//If image edit link is clicked
			$(".editLink").on('click', function(e){
				e.preventDefault();
				$("#fileInput:hidden").trigger('click');
			});

			//On select file to upload
			$("#fileInput").on('change', function(){
				var image = $('#fileInput').val();
				var img_ex = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
				
				//validate file type
				if(!img_ex.exec(image)){
					alert('Please upload only .jpg/.jpeg/.png/.gif file.');
					$('#fileInput').val('');
					return false;
				}else{
					$('.uploadProcess').show();
					$('#uploadForm').hide();
					$( "#picUploadForm" ).submit();
				}
			});
		});

		//After completion of image upload process
		function completeUpload(success, fileName) {
			if(success == 1){
				$('#imagePreview').attr("src", "");
				$('#imagePreview').attr("src", fileName);
				$('#fileInput').attr("value", fileName);
				$('.uploadProcess').hide();
			}else{
				$('.uploadProcess').hide();
				alert('There was an error during file upload!');
			}
			return true;
		}
	</script>
</body>
</html>