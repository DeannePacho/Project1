<?php
include_once 'Ajax/dbconfig.php';	
session_start();

	if(!isset($_SESSION['admin_session']))
	{
		header("Location: index.php");
	}

	$stmt = $db_con->prepare("SELECT * FROM admin WHERE admin_id=:uid");
	$stmt->execute(array(":uid"=>$_SESSION['admin_session']));
	$row=$stmt->fetch(PDO::FETCH_ASSOC);
	
?>

<!DOCTYPE html>
<html>
<head>
	<?php include('include/head.php'); ?>
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/media/css/jquery.dataTables.css">
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/media/css/responsive.dataTables.css">
</head>
<body>
	<?php include('include/header.php'); ?>
	<?php include('include/sidebar.php'); ?>
	<div class="main-container">
		<div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">

      <?php include("manage_statistics.php"); ?>

			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>DataTable</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Reports</a></li>
									<li class="breadcrumb-item active" aria-current="page">Subscribers Information</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>
				
				
				
				<!-- Export Datatable start -->
				<div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h5 class="text-blue">Subscriber Reports</h5>
						</div>
					</div>
					
					<div class="row">
						<table class="stripe hover multiple-select-row data-table-export nowrap" id="manageSubscribersTable">
							<thead>
								<tr>
									<th class="table-plus datatable-nosort">No.</th>									
									<th>Email Address</th>
									<th>DateTime</th>
								</tr>
							</thead>
							<tbody>

							</tbody>
						</table>
					</div>
				</div>
				<!-- Export Datatable End -->
			</div>
			<?php include('include/footer.php'); ?>
		</div>
	</div>
	<?php include('include/script.php'); ?>
	<script src="src/plugins/datatables/media/js/jquery.dataTables.min.js"></script>
	<script src="src/plugins/datatables/media/js/dataTables.bootstrap4.js"></script>
	<script src="src/plugins/datatables/media/js/dataTables.responsive.js"></script>
	<script src="src/plugins/datatables/media/js/responsive.bootstrap4.js"></script>
	<!-- buttons for Export datatable -->
	<script src="src/plugins/datatables/media/js/button/dataTables.buttons.js"></script>
	<script src="src/plugins/datatables/media/js/button/buttons.bootstrap4.js"></script>
	<script src="src/plugins/datatables/media/js/button/buttons.print.js"></script>
	<script src="src/plugins/datatables/media/js/button/buttons.html5.js"></script>
	<script src="src/plugins/datatables/media/js/button/buttons.flash.js"></script>
	<script src="src/plugins/datatables/media/js/button/pdfmake.min.js"></script>
	<script src="src/plugins/datatables/media/js/button/vfs_fonts.js"></script>
	<!--<script type="text/javascript" src="https://iexploresanfernando.000webhostapp.com/Admin/include/usersinformation/custom/js/index.js"></script>
-->
	<script type="text/javascript" src="include/subscribe_report/custom/js/index.js"></script>

</body>
</html>
