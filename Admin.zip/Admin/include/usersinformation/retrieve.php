
<?php

require_once '../../../Connections/dbconfig.php';

$output = array('data' => array());

$sql = "SELECT * FROM users";
$query = $db_conn->query($sql);

$x = 1;
while ($row = $query->fetch_assoc()) {
	$status = '';
	if($row['status'] == "Active") {
		$status = '<span style="color:green;"><i class="fa fa-check"> Active</span>';

	}else if($row['status'] == "Banned") {
		$status = '<span style="color:red;"><i class="fa fa-close"> Banned</label>';
	}

	$fullname = $row['firstname']. '&nbsp;'. $row['lastname'];

			
	$actionButton = '
	<div class="dropdown">
		<a class="btn btn-outline-primary dropdown-toggle" href="#" role="button" data-toggle="dropdown">
			<i class="fa fa-ellipsis-h"></i>
		</a>
		<div class="dropdown-menu dropdown-menu-right">
			<a class="dropdown-item" data-toggle="modal" data-target="#viewMemberModal" onclick="viewMember('.$row['user_id'].')"><i class="fa fa-eye"></i> View</a>
			<a class="dropdown-item" data-toggle="modal" data-target="#editMemberModal" onclick="editMember('.$row['user_id'].')" ><i class="fa fa-pencil"></i> Edit</a>
		</div>
	</div>';

	$output['data'][] = array(
		$x,
		$fullname,
		$row['username'],
		$status,
		$row['first_login'],
		$row['last_login'],
		$actionButton
	);

	$x++;
}

// database connection close
$db_conn->close();

echo json_encode($output);
?>
