<?php

require_once '../../../Connections/dbconfig.php';

//if form is submitted
if($_POST) {

	$validator = array('success' => false, 'messages' => array());

	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$username = $_POST['username'];
	$password = md5($_POST['password']);
	$email_address = $_POST['email_address'];
	$contact_number = $_POST['contact_number'];
	$diamonds = $_POST['diamonds'];
	$points = $_POST['points'];
	$first_login = $_POST['first_login'];
	$last_login = $_POST['last_login'];
	$status = $_POST['status'];


	$namecheckquery = "SELECT username FROM users WHERE username='".$username."';";

	$query =  mysqli_query($db_conn, $namecheckquery) or die("2: username check query failed"); // error code #2  username check  query failed

	if(mysqli_num_rows($query) > 0){

	}
	
	
	$sql = "INSERT INTO users (firstname, lastname, username, password, email_address, contact_number, diamonds, points, first_login, last_login,  status)
			VALUES ('$firstname','$lastname','$username','$password','$email_address','$contact_number','$diamonds','$points','$first_login','$last_login','$status')";
	$query = $db_conn->query($sql);
	

	if($query === TRUE) {
		$validator['success'] = true;
		$validator['messages'] = "Successfully Added";

	}else if($query === TRUE){
		$validator['success'] = true;
		$validator['messages'] = "Username Already Exist";

	} else {
		$validator['success'] = false;
		$validator['messages'] = "Error while adding the member information";
	}


	// close the database connection
	$db_conn->close();

	echo json_encode($validator);
	
}
