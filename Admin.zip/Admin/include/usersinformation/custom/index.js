// global the manage memeber table
var manageMemberTable;

$(document).ready(function() {
	manageMemberTable = $("#manageMemberTable").DataTable({
		"ajax": "include/usersinformation/retrieve.php",
		"order": []
	});


	$("#addMemberModalBtn").on('click', function() {
		// reset the form
		$("#createMemberForm")[0].reset();
		// remove the error
		$(".form-group").removeClass('has-error').removeClass('has-success');
		$(".text-danger").remove();
		// empty the message div
		$(".messages").html("");

		// submit form
		$("#createMemberForm").unbind('submit').bind('submit', function() {

			$(".text-danger").remove();

			var form = $(this);

			// validation
			var firstname = $("#firstname").val();
			var lastname = $("#lastname").val();
			var username = $("#username").val();
			var password = $("#password").val();
			var email_address = $("#email_address").val();
			var contact_number = $("#contact_number").val();
			var status = $("#status").val();

			if (firstname.trim() == "") {
				$("#firstname").closest('.form-group').addClass('has-error');
				$("#firstname").after('<p class="text-danger">The Firstname field is required</p>');
			} else {
				$("#firstname").closest('.form-group').removeClass('has-error');
				$("#firstname").closest('.form-group').addClass('has-success');
			}
			if (lastname.trim() == "") {
				$("#lastname").closest('.form-group').addClass('has-error');
				$("#lastname").after('<p class="text-danger">The Lastname field is required</p>');
			} else {
				$("#lastname").closest('.form-group').removeClass('has-error');
				$("#lastname").closest('.form-group').addClass('has-success');
			}
			if(username.trim() == "") {
				$("#username").closest('.form-group').addClass('has-error');
				$("#username").after('<p class="text-danger">The Username field is required</p>');
			} else {
				$("#username").closest('.form-group').removeClass('has-error');
				$("#username").closest('.form-group').addClass('has-success');
			}
			if (password.trim() == "") {
				$("#password").closest('.form-group').addClass('has-error');
				$("#password").after('<p class="text-danger">The Password field is required</p>');
			}else {
				$("#password").closest('.form-group').removeClass('has-error');
				$("#password").closest('.form-group').addClass('has-success');
			}
			if (email_address.trim() == "") {
				$("#email_address").closest('.form-group').addClass('has-error');
				$("#email_address").after('<p class="text-danger">The Email Address field is required</p>');
			} else {
				$("#email_address").closest('.form-group').removeClass('has-error');
				$("#email_address").closest('.form-group').addClass('has-success');
			}
			if (contact_number.trim() == "") {
				$("#contact_number").closest('.form-group').addClass('has-error');
				$("#contact_number").after('<p class="text-danger">The Contact Number field is required</p>');
			} else {
				$("#contact_number").closest('.form-group').removeClass('has-error');
				$("#contact_number").closest('.form-group').addClass('has-success');
			}
			if (status.trim() == "") {
				$("#status").closest('.form-group').addClass('has-error');
				$("#status").after('<p class="text-danger">The status field is required</p>');
			} else {
				$("#status").closest('.form-group').removeClass('has-error');
				$("#status").closest('.form-group').addClass('has-success');
			}

			if (firstname.trim() && lastname.trim() && username.trim() && password.trim() && email_address.trim() && contact_number.trim() && status.trim()) {
				//submi the form to server
				$.ajax({
					url : form.attr('action'),
					type : form.attr('method'),
					data : form.serialize(),
					dataType : 'json',
					success:function(response) {

						// remove the error
						$(".form-group").removeClass('has-error').removeClass('has-success');

						if(response.success == true) {
							$(".messages").html('<div class="alert alert-success alert-dismissible" role="alert">'+
							  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
							  '<strong> <span class="fa fa-check"></span> </strong>'+response.messages+
							'</div>');

							// reset the form
							$("#createMemberForm")[0].reset();

							// reload the datatables
							manageMemberTable.ajax.reload(null, false);
							// this function is built in function of datatables;

						} else {
							$(".messages").html('<div class="alert alert-warning alert-dismissible" role="alert">'+
							  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
							  '<strong> <span class="fa fa-exclamation-circle"></span> </strong>'+response.messages+
							'</div>');
						}  // /else
					} // success
				}); // ajax submit
			} /// if


			return false;
		}); // /submit form for create member
	}); // /add modal

});


function editMember(id = null) {
	if (id) {

		// remove the error
		$(".form-group").removeClass('has-error').removeClass('has-success');
		$(".text-danger").remove();
		// empty the message div
		$(".edit-messages").html("");

		// remove the id
		$("#member_id").remove();

		// fetch the member data
		$.ajax({
			url: 'include/usersinformation/getSelectedMember.php',
			type: 'post',
			data: { member_id: id },
			dataType: 'json',
			success: function (response) {

				$("#editFirstname").val(response.firstname);
				$("#editLastname").val(response.lastname);
				$("#editUsername").val(response.username);
				$("#editEmail_address").val(response.email_address);
				$("#editContact_number").val(response.contact_number);
				$("#editStatus").val(response.status);

				// member id
				$(".editMemberModal").append('<input type="hidden" name="member_id" id="member_id" value="' + response.user_id + '"/>');

				// here update the member data
				$("#updateMemberForm").unbind('submit').bind('submit', function () {
					// remove error messages
					$(".text-danger").remove();

					var form = $(this);

					// validation
					var editFirstname = $("#editFirstname").val();
					var editLastname = $("#editLastname").val();
					var editUsername = $("#editUsername").val();
					var editEmail_Address = $("#editEmail_Address").val();
					var editContact_number = $("#editContact_number").val();
					var editStatus = $("#editStatus").val();

					if (editFirstname == "") {
						$("#editFirstname").closest('.form-group').addClass('has-error');
						$("#editFirstname").after('<p class="text-danger">The Firstname field is required</p>');
					} else {
						$("#editFirstname").closest('.form-group').removeClass('has-error');
						$("#editFirstname").closest('.form-group').addClass('has-success');
					}
					if (editLastname == "") {
						$("#editLastname").closest('.form-group').addClass('has-error');
						$("#editLastname").after('<p class="text-danger">The Lastname field is required</p>');
					} else {
						$("#editLastname").closest('.form-group').removeClass('has-error');
						$("#editLastname").closest('.form-group').addClass('has-success');
					}
					if (editUsername == "") {
						$("#editUsername").closest('.form-group').addClass('has-error');
						$("#editUsername").after('<p class="text-danger">The Username field is required</p>');
					} else {
						$("#editUsername").closest('.form-group').removeClass('has-error');
						$("#editUsername").closest('.form-group').addClass('has-success');
					}
					if (editEmail_address == "") {
						$("#editEmail_address").closest('.form-group').addClass('has-error');
						$("#editEmail_address").after('<p class="text-danger">The Username field is required</p>');
					} else {
						$("#editEmail_address").closest('.form-group').removeClass('has-error');
						$("#editEmail_address").closest('.form-group').addClass('has-success');
					}
					if (editContact_number == "") {
						$("#editContact_number").closest('.form-group').addClass('has-error');
						$("#editContact_number").after('<p class="text-danger">The Contact Number field is required</p>');
					} else {
						$("#editContact_number").closest('.form-group').removeClass('has-error');
						$("#editContact_number").closest('.form-group').addClass('has-success');
					}
					if (editStatus == "") {
						$("#editStatus").closest('.form-group').addClass('has-error');
						$("#editStatus").after('<p class="text-danger">The Status field is required</p>');
					} else {
						$("#editStatus").closest('.form-group').removeClass('has-error');
						$("#editStatus").closest('.form-group').addClass('has-success');
					}
		


					if (editFirstname && editLastname && editUsername && editEmail_address && editContact_number && editStatus) {

						$.ajax({
							url: form.attr('action'),
							type: form.attr('method'),
							data: form.serialize(),
							dataType: 'json',
							success: function (response) {
								if (response.success == true) {
									$(".edit-messages").html('<div class="alert alert-success alert-dismissible" role="alert">' +
										'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
										'<strong> <span class="fa fa-check"></span> </strong>' + response.messages +
										'</div>');

									// reload the datatables
									manageMemberTable.ajax.reload(null, false);
									// this function is built in function of datatables;

									// remove the error
									$(".form-group").removeClass('has-success').removeClass('has-error');
									$(".text-danger").remove();
								} else {
									$(".edit-messages").html('<div class="alert alert-warning alert-dismissible" role="alert">' +
										'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
										'<strong> <span class="fa fa-exclamation-circle"></span> </strong>' + response.messages +
										'</div>')
								}
							} // /success
						}); // /ajax
					} // /if

					return false;
				});

			} // /success
		}); // /fetch selected member info

	} else {
		alert("Error : Refresh the page again");
	}
}

function viewMember(id = null) {
	if (id) {

		// remove the error
		$(".form-group").removeClass('has-error').removeClass('has-success');
		$(".text-danger").remove();
		// empty the message div
		$(".edit-messages").html("");

		// remove the id
		$("#member_id").remove();

		// fetch the member data
		$.ajax({
			url: 'include/usersinformation/getSelectedMember.php',
			type: 'post',
			data: { member_id: id },
			dataType: 'json',
			success: function (response) {

				$("#viewFirstname").val(response.firstname);
				$("#viewLastname").val(response.lastname);
				$("#viewUsername").val(response.username);
				$("#viewEmail_address").val(response.email_address);
				$("#viewContact_number").val(response.contact_number);
				$("#viewFirst_login").val(response.first_login);
				$("#viewLast_login").val(response.last_login);
				$("#viewDiamonds").val(response.diamonds);
				$("#viewPoints").val(response.points);
				$("#viewStatus").val(response.status);

				// member id
				$(".viewMemberModal").append('<input type="hidden" name="member_id" id="member_id" value="' + response.user_id + '"/>');

			} // /success
		}); // /fetch selected member info

	} else {
		alert("Error : Refresh the page again");
	}
}
