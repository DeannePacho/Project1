<?php

require_once '../../../Connections/dbconfig.php';

//if form is submitted
if($_POST) {

	$validator = array('success' => false, 'messages' => array());

	$id = $_POST['member_id'];
	$firstname = $_POST['editFirstname'];
	$lastname = $_POST['editLastname'];
	$username = $_POST['editUsername'];
	$email_address = $_POST['editEmail_address'];
	$contact_number = $_POST['editContact_number'];
	$status = $_POST['editStatus'];

	$sql = "UPDATE users SET firstname = '$firstname', lastname = '$lastname', username = '$username', email_address = '$email_address', contact_number = '$contact_number', status = '$status'  WHERE user_id = $id";
	$query = $db_conn->query($sql);

	if($query === TRUE) {
		$validator['success'] = true;
		$validator['messages'] = "Successfully Edited";
	} else {
		$validator['success'] = false;
		$validator['messages'] = "Error while adding the member information";
	}

	// close the database connection
	$db_conn->close();

	echo json_encode($validator);

}
