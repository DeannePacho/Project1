	<div class="left-side-bar">
		<div class="brand-logo">
			<a href="manage_dashboard.php">
				<img src="vendors/images/iexplore_logo.png" alt="">
			</a>
		</div>
		<div class="menu-block customscroll">
			<div class="sidebar-menu">
				<ul id="accordion-menu">
					<li class="dropdown">
						<a  href="manage_dashboard.php" class="dropdown-toggle">
							<span class="fa fa-home"></span><span class="mtext">Dashboard</span>
						</a>
						
					</li>

					<li class="dropdown">
						<a href="manage_accounts.php" class="dropdown-toggle">
							<span class="fa fa-users"></span><span class="mtext">Accounts</span>
						</a>						
					</li>

					<li class="dropdown">
						<a href="manage_achievements.php" class="dropdown-toggle">
							<span class="fa fa-trophy"></span><span class="mtext">Achievements</span>
						</a>			
					</li>

					<li class="dropdown">
						<a href="manage_announcements.php" class="dropdown-toggle">
							<span class="fa fa-bullhorn"></span><span class="mtext">Notice</span>
						</a>
					</li>

					<li class="dropdown">
						<a href="manage_events.php" class="dropdown-toggle">
							<span class="fa fa-calendar"></span><span class="mtext">Events</span>
						</a>
					</li>

					<li class="dropdown">
						<a href="manage_tasks.php" class="dropdown-toggle">
							<span class="fa fa-tasks"></span><span class="mtext">Tasks</span>
						</a>
					</li>

					<li class="dropdown">
						<a href="manage_tourist_spots.php" class="dropdown-toggle">
							<span class="fa fa-location-arrow"></span><span class="mtext">Tourist Spots</span>
						</a>
					</li>

					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="fa fa-list"></span><span class="mtext">Reports</span>
						</a>
						<ul class="submenu">
							<li><a href="manage_problems_report.php">Problems Report</a></li>
							<li><a href="manage_feedbacks_report.php">Feedbacks Report</a></li>
							<li><a href="manage_subscribers_report.php">Subscribers Report</a></li>
						</ul>
					</li>


					<li class="dropdown">
						<a href="manage_sponsors.php" class="dropdown-toggle">
							<span class="fa fa-location-arrow"></span><span class="mtext">Sponsors</span>
						</a>
					</li>

					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="fa fa-pencil"></span><span class="mtext">Settings</span>
						</a>
						<ul class="submenu">
							<li><a href="manage_maintenance.php">Maintenance</a></li>
							<li><a href="manage_system_informations.php">System Informations</a></li>
						</ul>
					</li>

					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="fa fa-clone"></span><span class="mtext">Extra Pages</span>
						</a>
						<ul class="submenu">
								<li><a href="manage_about_iexplore.php">About IExplore</a></li>
							<li><a href="manage_faq.php">FAQ</a></li>
						</ul>
					</li>
				</ul>
			</div>
		</div>
	</div>
