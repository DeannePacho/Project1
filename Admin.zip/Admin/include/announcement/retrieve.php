
<?php

require_once '../../../Connections/dbconfig.php';

$output = array('data' => array());

$sql = "SELECT * FROM notice";
$query = $db_conn->query($sql);

$x = 1;
while ($row = $query->fetch_assoc()) {

			
	$actionButton = '
	<div class="dropdown">
		<a class="btn btn-outline-primary dropdown-toggle" href="#" role="button" data-toggle="dropdown">
			<i class="fa fa-ellipsis-h"></i>
		</a>
		<div class="dropdown-menu dropdown-menu-right">
			<a class="dropdown-item" data-toggle="modal" data-target="#viewMemberModal" onclick="viewMember('.$row['notice_id'].')"><i class="fa fa-eye"></i> View</a>
			<a class="dropdown-item" data-toggle="modal" data-target="#editMemberModal" onclick="editMember('.$row['notice_id'].')" ><i class="fa fa-pencil"></i> Edit</a>
		</div>
	</div>';

	$output['data'][] = array(
		$x,
		$row['image'],
		$row['title'],
		$row['date'],
		$actionButton
	);

	$x++;
}

// database connection close
$db_conn->close();

echo json_encode($output);
?>
