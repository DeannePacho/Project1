// global the manage memeber table
var manageNoticeTable;

$(document).ready(function() {
	manageNoticeTable = $("#manageNoticeTable").DataTable({
		"ajax": "include/announcement/retrieve.php",
		"order": []
	});


	$("#addMemberModalBtn").on('click', function() {
		// reset the form
		$("#createMemberForm")[0].reset();
		// remove the error
		$(".form-group").removeClass('has-error').removeClass('has-success');
		$(".text-danger").remove();
		// empty the message div
		$(".messages").html("");

		// submit form
		$("#createMemberForm").unbind('submit').bind('submit', function() {

			$(".text-danger").remove();

			var form = $(this);

			// validation
			var title = $("#title").val();
			var description = $("#description").val();


			if (title.trim() == "") {
				$("#title").closest('.form-group').addClass('has-error');
				$("#title").after('<p class="text-danger">The Title field is required</p>');
			} else {
				$("#title").closest('.form-group').removeClass('has-error');
				$("#title").closest('.form-group').addClass('has-success');
			}
			if (description.trim() == "") {
				$("#description").closest('.form-group').addClass('has-error');
				$("#description").after('<p class="text-danger">The Description field is required</p>');
			} else {
				$("#description").closest('.form-group').removeClass('has-error');
				$("#description").closest('.form-group').addClass('has-success');
			}


			if (title.trim() && description.trim()) {
				//submi the form to server
				$.ajax({
					url : form.attr('action'),
					type : form.attr('method'),
					data : form.serialize(),
					dataType : 'json',
					success:function(response) {

						// remove the error
						$(".form-group").removeClass('has-error').removeClass('has-success');

						if(response.success == true) {
							$(".messages").html('<div class="alert alert-success alert-dismissible" role="alert">'+
							  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
							  '<strong> <span class="fa fa-check"></span> </strong>'+response.messages+
							'</div>');

							// reset the form
							$("#createMemberForm")[0].reset();

							// reload the datatables
							manageNoticeTable.ajax.reload(null, false);
							// this function is built in function of datatables;

						} else {
							$(".messages").html('<div class="alert alert-warning alert-dismissible" role="alert">'+
							  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
							  '<strong> <span class="fa fa-exclamation-circle"></span> </strong>'+response.messages+
							'</div>');
						}  // /else
					} // success
				}); // ajax submit
			} /// if


			return false;
		}); // /submit form for create member
	}); // /add modal

});


function editMember(id = null) {
	if (id) {

		// remove the error
		$(".form-group").removeClass('has-error').removeClass('has-success');
		$(".text-danger").remove();
		// empty the message div
		$(".edit-messages").html("");

		// remove the id
		$("#member_id").remove();

		// fetch the member data
		$.ajax({
			url: 'include/announcement/getSelectedMember.php',
			type: 'post',
			data: { member_id: id },
			dataType: 'json',
			success: function (response) {

				$("#editTitle").val(response.title);
				$("#editDescription").val(response.description);

				// member id
				$(".editMemberModal").append('<input type="hidden" name="member_id" id="member_id" value="' + response.notice_id + '"/>');

				// here update the member data
				$("#updateMemberForm").unbind('submit').bind('submit', function () {
					// remove error messages
					$(".text-danger").remove();

					var form = $(this);

					// validation
					var editTitle = $("#editTitle").val();
					var editDescription = $("#editDescription").val();

					if (editTitle == "") {
						$("#editTitle").closest('.form-group').addClass('has-error');
						$("#editTitle").after('<p class="text-danger">The Firstname field is required</p>');
					} else {
						$("#editTitle").closest('.form-group').removeClass('has-error');
						$("#editTitle").closest('.form-group').addClass('has-success');
					}
					if (editDescription == "") {
						$("#editDescription").closest('.form-group').addClass('has-error');
						$("#editDescription").after('<p class="text-danger">The Lastname field is required</p>');
					} else {
						$("#editDescription").closest('.form-group').removeClass('has-error');
						$("#editDescription").closest('.form-group').addClass('has-success');
					}

					if (editTitle && editDescription) {

						$.ajax({
							url: form.attr('action'),
							type: form.attr('method'),
							data: form.serialize(),
							dataType: 'json',
							success: function (response) {
								if (response.success == true) {
									$(".edit-messages").html('<div class="alert alert-success alert-dismissible" role="alert">' +
										'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
										'<strong> <span class="fa fa-check"></span> </strong>' + response.messages +
										'</div>');

									// reload the datatables
									manageMemberTable.ajax.reload(null, false);
									// this function is built in function of datatables;

									// remove the error
									$(".form-group").removeClass('has-success').removeClass('has-error');
									$(".text-danger").remove();
								} else {
									$(".edit-messages").html('<div class="alert alert-warning alert-dismissible" role="alert">' +
										'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
										'<strong> <span class="fa fa-exclamation-circle"></span> </strong>' + response.messages +
										'</div>')
								}
							} // /success
						}); // /ajax
					} // /if

					return false;
				});

			} // /success
		}); // /fetch selected member info

	} else {
		alert("Error : Refresh the page again");
	}
}

function viewMember(id = null) {
	if (id) {

		// remove the error
		$(".form-group").removeClass('has-error').removeClass('has-success');
		$(".text-danger").remove();
		// empty the message div
		$(".edit-messages").html("");

		// remove the id
		$("#member_id").remove();

		// fetch the member data
		$.ajax({
			url: 'include/announcement/getSelectedMember.php',
			type: 'post',
			data: { member_id: id },
			dataType: 'json',
			success: function (response) {

				$("#viewTitle").val(response.title);
				$("#viewDescription").val(response.description);

				// member id
				$(".viewMemberModal").append('<input type="hidden" name="member_id" id="member_id" value="' + response.notice_id + '"/>');

			} // /success
		}); // /fetch selected member info

	} else {
		alert("Error : Refresh the page again");
	}
}
