<?php

require_once '../../../Connections/dbconfig.php';

$memberId = $_POST['member_id'];

$sql = "SELECT * FROM notice WHERE notice_id = $memberId";
$query = $db_conn->query($sql);
$result = $query->fetch_assoc();

$db_conn->close();

echo json_encode($result);
