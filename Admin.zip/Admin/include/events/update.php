<?php

require_once '../../../Connections/dbconfig.php';

//if form is submitted
if($_POST) {

	$validator = array('success' => false, 'messages' => array());

	$id = $_POST['member_id'];
	$title = $_POST['editTitle'];
	$description = $_POST['editDescription'];


	$sql = "UPDATE events SET title = '$title', description = '$description' WHERE event_id = $id";
	$query = $db_conn->query($sql);

	if($query === TRUE) {
		$validator['success'] = true;
		$validator['messages'] = "Successfully Edited";
	} else {
		$validator['success'] = false;
		$validator['messages'] = "Error while adding the member information";
	}

	// close the database connection
	$db_conn->close();

	echo json_encode($validator);

}
