<?php

require_once '../../../Connections/dbconfig.php';

//if form is submitted
if($_POST) {

	$validator = array('success' => false, 'messages' => array());

	$title = $_POST['title'];
	$description = $_POST['description'];
	
	$namecheckquery = "SELECT title FROM events WHERE title='".$title."';";

	$query =  mysqli_query($db_conn, $namecheckquery) or die("2: title check query failed"); // error code #2  username check  query failed

	if(mysqli_num_rows($query) > 0){

	}
	
	
	$sql = "INSERT INTO events (title, description)
			VALUES ('$title','$description')";
	$query = $db_conn->query($sql);
	

	if($query === TRUE) {
		$validator['success'] = true;
		$validator['messages'] = "Successfully Added";

	}else if($query === TRUE){
		$validator['success'] = true;
		$validator['messages'] = "Title Already Exist";

	} else {
		$validator['success'] = false;
		$validator['messages'] = "Error while adding the member information";
	}


	// close the database connection
	$db_conn->close();

	echo json_encode($validator);
	
}
