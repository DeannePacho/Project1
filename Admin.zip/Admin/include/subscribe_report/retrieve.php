
<?php

require_once '../../../Connections/dbconfig.php';

$output = array('data' => array());

$sql = "SELECT * FROM subscriber";
$query = $db_conn->query($sql);

$x = 1;
while ($row = $query->fetch_assoc()) {

	$output['data'][] = array(
		$x,
		$row['email_address'],
		$row['datetime'],		
	);

	$x++;
}

// database connection close
$db_conn->close();

echo json_encode($output);
?>
