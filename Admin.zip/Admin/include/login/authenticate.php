<?php
	session_start();
	require_once '../../Ajax/dbconfig.php';

	if(isset($_POST['login']))
	{
		//$user_name = $_POST['user_name'];
		$username = trim($_POST['username']);
		$password = md5(trim($_POST['password']));

		$password = $password;

		try
		{
			$stmt = $db_con->prepare("SELECT * FROM admin WHERE username=:uusername");
			$stmt->execute(array(":uusername"=>$username));
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$count = $stmt->rowCount();

			if($row['password']== $password)
			{

				echo "ok"; // log in
				$_SESSION['admin_session'] = $row['admin_id'];
			}
			else
			{
				echo "username or password are incorrect."; // wrong details
			}

		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}

?>
