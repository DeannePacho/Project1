
<?php

require_once '../../../Connections/dbconfig.php';

$output = array('data' => array());



$sql = "SELECT * FROM users ORDER BY rank DESC";
$query = $db_conn->query($sql);

$x = 1;
while ($row = $query->fetch_assoc()) {

	$fullname = $row['firstname']. '&nbsp;'. $row['lastname'];



	$output['data'][] = array(
		$x,
		$fullname,
		$row['username'],
		$row['rank'],
		$row['points']

	);

	$x++;
}

// database connection close
$db_conn->close();

echo json_encode($output);
?>
