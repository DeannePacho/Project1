<?php

require_once '../../../Connections/dbconfig.php';

$reportId = $_POST['report_id'];

$sql = "SELECT * FROM users WHERE user_id = $reportId";
$query = $db_conn->query($sql);
$result = $query->fetch_assoc();

$db_conn->close();

echo json_encode($result);
