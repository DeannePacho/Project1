// global the manage memeber table
var manageLeaderBoard;

$(document).ready(function() {
	manageLeaderBoard = $("#manageLeaderBoard").DataTable({
		"ajax": "include/leaderboard/retrieve.php",
		"order": []
	});
});