	<div class="footer-wrap bg-white pd-20 mb-20 border-radius-5 box-shadow">
		i-Explore By <a href="" target="_blank">San Fernando La Union </a>
	</div>