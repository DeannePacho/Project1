<?php
	include('../../../Connections/dbconfig.php');
	if(isset($_POST['show'])){
		?>
				<div class="gallery-wrap">
					<ul class="row">
					<?php 	
						
						$sql = "SELECT * FROM tourist_spots Where status='archive'";
						$query = $db_conn->query($sql);
						
						$x = 1;
						while ($row1 = $query->fetch_assoc()) {
							
					?>					
							<li class="col-lg-4 col-md-6 col-sm-12">
								<div class="da-card box-shadow">
								<h5 class="mb-5 color-black pd-20"><?php echo $x ?>).<?php echo $row1['tourist_spot_name'] ?></h5>
									<div class="da-card-photo">
										<img src="vendors/images/product-img1.jpg" alt="">						
										<div class="da-overlay">
											<div class="da-social">
												<ul class="clearfix">
													<li><a href="vendors/tourist_spots_images/product-img1.jpg" data-fancybox="images"><i class="fa fa-picture-o"></i></a></li>
													<li><a href="#" data-toggle="modal" data-target="#edit<?php echo $row1['tourist_spot_id']; ?>"><i class="fa fa-edit"></i></a></li>
													<li><a href="#" data-toggle="modal" data-target="#archive<?php echo $row1['tourist_spot_id']; ?>"><i class="fa fa-archive"></i></a></li>	
												</ul>
											</div>
										</div>
									</div>
								</div>
								
								
								<?php include "edit_modal.php"; ?>
								<?php include "unarchive_modal.php"; ?>
							</li>
							
							
							
		

					<?php 
					
						$x++;

							
						}
						
					?>	
					
					</ul>				
				</div>
				
		<?php
	}
?>

	