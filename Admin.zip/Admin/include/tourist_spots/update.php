<?php
	include('../../../Connections/dbconfig.php');
	if(isset($_POST['edit'])){
		$id=$_POST['id'];
		$tourist_spot_name=$_POST['tourist_spot_name'];
		$address=$_POST['address'];
		$description=$_POST['description'];
		
		mysqli_query($db_conn,"update `tourist_spots` set tourist_spot_name='$tourist_spot_name', address='$address', description='$description' where tourist_spot_id='$id'");
	}
?>