<?php
	include('../../../Connections/dbconfig.php');
	if(isset($_POST['archive'])){
		$id=$_POST['id'];
		$status=$_POST['status'];
		
		mysqli_query($db_conn,"update `tourist_spots` set status='$status' where tourist_spot_id='$id'");
	}
?>