
			<!--Modal Add Account Start-->
				<!-- Large modal -->
				<div class="col-md-4 col-sm-12">
					<div class="modal fade bs-example-modal-lg" id="archive<?php echo $row1['tourist_spot_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
						<?php
							$n=mysqli_query($db_conn,"select * from `tourist_spots` where tourist_spot_id='".$row1['tourist_spot_id']."'");
							$nrow=mysqli_fetch_array($n);
						?>
						<div class="modal-dialog modal-lg modal-dialog-centered">
							<div class="modal-content">
								<div class="modal-header">
									<h4 class="modal-title" id="myLargeModalLabel"><i class="fa fa-check"></i> Archive Tourist Spot</h4>
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
								</div>
								<div class="modal-body">
									<form method="POST">
										 <div class="col-xl-12 col-lg-8 col-md-8 col-sm-12 mb-30">
											<div class="bg-white border-radius-4 box-shadow height-100-p">
												<div class="profile-tab height-100-p">
													<div class="tab height-100-p">
														<div class="tab-content">
															<!-- Information Panel start -->
																<div class="notification-list mx-h-450 customscroll">
																	<div class="pd-20">
																		<div class="profile-timeline">
																			<div class="messages"></div>
																			<h5>Are You Sure You Want To Unarchive
																			<b style="color:green;"><?php echo $row1['tourist_spot_name'] ?></b> ?</h5>
																			<input type="hidden" class="form-control form-control-lg" name="unarchive" value="unarchive" id="ustatus<?php echo $row1['tourist_spot_id']; ?>" placeholder="Address:">
																					
																		</div>
																	</div>
																</div>
															<!-- Information Panel End -->
														</div>
													 </div>
												 </div>
											 </div>
										 </div>
										<div class="modal-footer">
											<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
											<button type="button" value="<?php echo $row1['tourist_spot_id']; ?>" class="archiveuser btn btn-primary">Save changes</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--Modal Add Account End-->
