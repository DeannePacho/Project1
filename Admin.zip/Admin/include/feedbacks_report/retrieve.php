
<?php

require_once '../../../Connections/dbconfig.php';

$output = array('data' => array());

$sql = "SELECT * FROM feedback";
$query = $db_conn->query($sql);

$x = 1;
while ($row = $query->fetch_assoc()) {

	$fullname = $row['firstname']. '&nbsp;'. $row['lastname'];


	$actionButton = '
	<div class="dropdown">
		<a class="btn btn-outline-primary dropdown-toggle" href="#" role="button" data-toggle="dropdown">
			<i class="fa fa-ellipsis-h"></i>
		</a>
		<div class="dropdown-menu dropdown-menu-right">
			<a class="dropdown-item" data-toggle="modal" data-target="#viewMemberModal" onclick="viewMember('.$row['feedback_id'].')"><i class="fa fa-envelope"></i> View Message</a>
		</div>
	</div>';

	$output['data'][] = array(
		$x,
		$row['date'],
		$fullname,
		$row['status'],
		$actionButton
	);

	$x++;
}

// database connection close
$db_conn->close();

echo json_encode($output);
?>
