// global the manage memeber table
var manageFeedbacksreportTable;

$(document).ready(function() {
	manageFeedbacksreportTable = $("#manageFeedbacksreportTable").DataTable({
		"ajax": "include/feedbacks_report/retrieve.php",
		"order": []
	});
});


function editMember(id = null) {
	if (id) {

		// remove the error
		$(".form-group").removeClass('has-error').removeClass('has-success');
		$(".text-danger").remove();
		// empty the message div
		$(".edit-messages").html("");

		// remove the id
		$("#report_id").remove();

		// fetch the member data
		$.ajax({
			url: 'include/usersinformation/getSelectedMember.php',
			type: 'post',
			data: { report_id: id },
			dataType: 'json',
			success: function (response) {

				$("#editFirstname").val(response.firstname);
				$("#editLastname").val(response.lastname);
				$("#editUsername").val(response.username);
				$("#editEmail_address").val(response.email_address);
				$("#editContact_number").val(response.contact_number);
				$("#editStatus").val(response.status);

				// member id
				$(".editMemberModal").append('<input type="hidden" name="report_id" id="report_id" value="' + response.user_id + '"/>');

				// here update the member data
				$("#updateMemberForm").unbind('submit').bind('submit', function () {
					// remove error messages
					$(".text-danger").remove();

					var form = $(this);

					// validation
					var editFirstname = $("#editFirstname").val();
					var editLastname = $("#editLastname").val();
					var editUsername = $("#editUsername").val();
					var editEmail_Address = $("#editEmail_Address").val();
					var editContact_number = $("#editContact_number").val();
					var editStatus = $("#editStatus").val();

					if (editFirstname == "") {
						$("#editFirstname").closest('.form-group').addClass('has-error');
						$("#editFirstname").after('<p class="text-danger">The Firstname field is required</p>');
					} else {
						$("#editFirstname").closest('.form-group').removeClass('has-error');
						$("#editFirstname").closest('.form-group').addClass('has-success');
					}
					if (editLastname == "") {
						$("#editLastname").closest('.form-group').addClass('has-error');
						$("#editLastname").after('<p class="text-danger">The Lastname field is required</p>');
					} else {
						$("#editLastname").closest('.form-group').removeClass('has-error');
						$("#editLastname").closest('.form-group').addClass('has-success');
					}
					if (editUsername == "") {
						$("#editUsername").closest('.form-group').addClass('has-error');
						$("#editUsername").after('<p class="text-danger">The Username field is required</p>');
					} else {
						$("#editUsername").closest('.form-group').removeClass('has-error');
						$("#editUsername").closest('.form-group').addClass('has-success');
					}
					if (editEmail_address == "") {
						$("#editEmail_address").closest('.form-group').addClass('has-error');
						$("#editEmail_address").after('<p class="text-danger">The Username field is required</p>');
					} else {
						$("#editEmail_address").closest('.form-group').removeClass('has-error');
						$("#editEmail_address").closest('.form-group').addClass('has-success');
					}
					if (editContact_number == "") {
						$("#editContact_number").closest('.form-group').addClass('has-error');
						$("#editContact_number").after('<p class="text-danger">The Contact Number field is required</p>');
					} else {
						$("#editContact_number").closest('.form-group').removeClass('has-error');
						$("#editContact_number").closest('.form-group').addClass('has-success');
					}
					if (editStatus == "") {
						$("#editStatus").closest('.form-group').addClass('has-error');
						$("#editStatus").after('<p class="text-danger">The Status field is required</p>');
					} else {
						$("#editStatus").closest('.form-group').removeClass('has-error');
						$("#editStatus").closest('.form-group').addClass('has-success');
					}
		


					if (editFirstname && editLastname && editUsername && editEmail_address && editContact_number && editStatus) {

						$.ajax({
							url: form.attr('action'),
							type: form.attr('method'),
							data: form.serialize(),
							dataType: 'json',
							success: function (response) {
								if (response.success == true) {
									$(".edit-messages").html('<div class="alert alert-success alert-dismissible" role="alert">' +
										'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
										'<strong> <span class="fa fa-check"></span> </strong>' + response.messages +
										'</div>');

									// reload the datatables
									manageProblemsreportTable.ajax.reload(null, false);
									// this function is built in function of datatables;

									// remove the error
									$(".form-group").removeClass('has-success').removeClass('has-error');
									$(".text-danger").remove();
								} else {
									$(".edit-messages").html('<div class="alert alert-warning alert-dismissible" role="alert">' +
										'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
										'<strong> <span class="fa fa-exclamation-circle"></span> </strong>' + response.messages +
										'</div>')
								}
							} // /success
						}); // /ajax
					} // /if

					return false;
				});

			} // /success
		}); // /fetch selected member info

	} else {
		alert("Error : Refresh the page again");
	}
}

function viewMember(id = null) {
	if (id) {

		// remove the error
		$(".form-group").removeClass('has-error').removeClass('has-success');
		$(".text-danger").remove();
		// empty the message div
		$(".edit-messages").html("");

		// remove the id
		$("#report_id").remove();

		// fetch the member data
		$.ajax({
			url: 'include/usersinformation/getSelectedMember.php',
			type: 'post',
			data: { report_id: id },
			dataType: 'json',
			success: function (response) {

				$("#viewFirstname").val(response.firstname);
				$("#viewLastname").val(response.lastname);
				$("#viewUsername").val(response.username);
				$("#viewEmail_address").val(response.email_address);
				$("#viewContact_number").val(response.contact_number);
				$("#viewFirst_login").val(response.first_login);
				$("#viewLast_login").val(response.last_login);
				$("#viewDiamonds").val(response.diamonds);
				$("#viewPoints").val(response.points);
				$("#viewStatus").val(response.status);

				// member id
				$(".viewMemberModal").append('<input type="hidden" name="report_id" id="report_id" value="' + response.user_id + '"/>');

			} // /success
		}); // /fetch selected member info

	} else {
		alert("Error : Refresh the page again");
	}
}


