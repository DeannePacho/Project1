<?php  
    use PHPMailer\PHPMailer\PHPMailer;
    
    
    if(isset($_POST['email_address'])) {

        $conn = new mysqli('localhost' , 'root', '', 'iexplore');
        
        $email_address = $_POST['email_address'];
        

        $sql = $conn->query("SELECT admin_id FROM admin WHERE  email_address= '$email_address'");
        if($sql->num_rows > 0 ){

            $token = "abcdefghijklmnopqrstuvwxyz";
            $token = str_shuffle($token);
            $token = substr($token, 0, 10);

            $conn->query("UPDATE admin SET token ='$token', tokenExpire=DATE_ADD(NOW(), INTERVAL 5 MINUTE) WHERE email_address='$email_address'");

            require_once "PHPMailer/PHPMailer.php";
        	require_once "PHPMailer/Exception.php";

            $mail = new PHPMailer();
	        $mail->addAddress($email_address);
	        $mail->setFrom("hello@iexploresanfernando.000webhostapp.com", "IExploreSFC");
	        $mail->Subject = "Reset Password";
	        $mail->isHTML(true);
	        $mail->Body = "
            
                Hi, <br><br>

                In order to reset your password please click on the link below: <br>
                <a href='https://iexploresanfernando.000webhostapp.com/Admin/include/forgotpassword/resetpassword.php?email_address=$email_address&token=$token'>
                https://iexploresanfernando.000webhostapp.com/Admin/include/forgotpassword/resetpassword.php?email_address=$email_address&token=$token'</a><br><br>

                Kinds Regards,<br>
                IExplore SFC.
            ";

           if ($mail->send())
    	        exit(json_encode(array("status" => 1, "msg" => 'Please Check Your Email Inbox!')));
    	    else
    	        exit(json_encode(array("status" => 0, "msg" => 'Something Wrong Just Happened! Please try again!')));
        } else
            exit(json_encode(array("status" => 0, "msg" => 'Please Check Your Inputs!')));
    }


?>