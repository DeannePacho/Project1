<?php
include_once 'Ajax/dbconfig.php';	
session_start();

	if(!isset($_SESSION['admin_session']))
	{
		header("Location: index.php");
	}

	$stmt = $db_con->prepare("SELECT * FROM admin WHERE admin_id=:uid");
	$stmt->execute(array(":uid"=>$_SESSION['admin_session']));
	$row=$stmt->fetch(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html>
<head>
	<?php include('include/head.php'); ?>
	<!-- fancybox Popup css -->
	<link rel="stylesheet" type="text/css" href="src/plugins/fancybox/dist/jquery.fancybox.css">
</head>
<body>
	<?php include('include/header.php'); ?>
	<?php include('include/sidebar.php'); ?>
	<div class="main-container">
		<div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">
			
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-12 col-sm-12">
							<div class="title">
								<h4>Tourist Spots</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Tourist Spots</a></li>
									<li class="breadcrumb-item active" aria-current="page">Tourist Spots Information</li>
								</ol>
							</nav>
						</div>
						<div class="col-md-12 col-sm-12 text-right">
							<div class="dropdown">
								<a class="btn btn-danger" href="manage_tourist_spots.php">
									<i class="fa fa-backward"></i> Back
								</a>
							</div>
						</div>
					</div>
				</div><br>
				
				
				
				
				
				
				
				<div class="row">
					<div id="userTable"></div>
				</div>
				
			</div>
			<?php include('include/footer.php'); ?>
		</div>
	</div>
	<?php include('include/script.php'); ?>
	<!-- fancybox Popup Js -->
	<script src="src/plugins/fancybox/dist/jquery.fancybox.js"></script>
	
	<script type = "text/javascript">
		$(document).ready(function(){
			showUser();
			//Add New
			
			
			$(document).on('click', '#addnew', function(){
				if ($('#tourist_spot_name').val()=="" || $('#address').val()=="" || $('#description').val()==""){
					alert('Please input data first');
				}
				else{
				$tourist_spot_name=$('#tourist_spot_name').val();
				$address=$('#address').val();
				$description=$('#description').val();
				$status=$('#status').val();
				
					$.ajax({
						type: "POST",
						url: "include/tourist_spots/addnew.php",
						data: {
							tourist_spot_name: $tourist_spot_name,
							address: $address,		
							description: $description,
							status: $status,
							add: 1,
						},
						success: function(){
							showUser();
						}
					});
				}
			});
			
			//Delete
			$(document).on('click', '.delete', function(){
				$id=$(this).val();
					$.ajax({
						type: "POST",
						url: "delete.php",
						data: {
							id: $id,
							del: 1,
						},
						success: function(){
							showUser();
						}
					});
			});
			
			//Update
			$(document).on('click', '.updateuser', function(){
				$uid=$(this).val();
				$('#edit'+$uid).modal('hide');
				
				$('body').removeClass('modal-open');
				$('.modal-backdrop').remove();
				
				$utourist_spot_name=$('#utourist_spot_name'+$uid).val();
				$uaddress=$('#uaddress'+$uid).val();
				$udescription=$('#udescription'+$uid).val();
				
					$.ajax({
						type: "POST",
						url: "include/tourist_spots/update.php",
						data: {
							id: $uid,
							tourist_spot_name: $utourist_spot_name,
							address: $uaddress,
							description: $udescription,
							edit: 1,
						},
						success: function(){
							showUser();
						}
					});
			});
			
			
			//Archive
			$(document).on('click', '.archiveuser', function(){
				$uid=$(this).val();
				$('#archive'+$uid).modal('hide');
				
				$('body').removeClass('modal-open');
				$('.modal-backdrop').remove();
				
				$ustatus=$('#ustatus'+$uid).val();
				
				$.ajax({
					type: "POST",
					url: "include/tourist_spots/archive.php",
					data: {
						id: $uid,
						status: $ustatus,
						archive: 1,
					},
					success: function(){
						showUser();
					}
				});
			});
			

		
		});
		
		//Showing our Table
		function showUser(){
			$.ajax({
				url: 'include/tourist_spots/show_archive.php',
				type: 'POST',
				async: false,
				data:{
					show: 1
				},
				success: function(response){
					$('#userTable').html(response);
				}
			});
		}
		
	</script>
</body>
</html>
