<div class="page-header">
  <div class="row">
    <div class="col-md-6 col-sm-12">
      <div class="title">
        <h4>Statistics</h4>
      </div>
      <nav aria-label="breadcrumb" role="navigation">
        <ol class="breadcrumb">
         
        </ol>
      </nav>
    </div>
  </div>
</div>

<div class="row clearfix progress-box">

  <!--Problem Reports Start-->
  <div class="col-lg-3 col-md-6 col-sm-12 mb-30">
    <div class="bg-white pd-20 box-shadow border-radius-5 height-100-p">
      <div class="project-info clearfix">
        <div class="project-info-left">
          <div class="icon box-shadow bg-blue text-white">
            <i class="fa fa-list"></i>
          </div>
        </div>
		<?php 
			
			$stmt = $db_con->prepare("SELECT COUNT(problem_reports_id) FROM problem_reports");
			$stmt->execute();
			$row=$stmt->fetch(PDO::FETCH_ASSOC);			
		
		?>
        <div class="project-info-right">
          <span class="no text-blue weight-500 font-24"><?php echo $row['COUNT(problem_reports_id)']; ?></span>
          <p class="weight-400 font-18">Problem Reports</p>
        </div>
      </div>
      <div class="project-info-progress">
        <div class="row clearfix">
          <div class="col-sm-6 text-muted weight-500">Stats</div>
          <div class="col-sm-6 text-right weight-500 font-14 text-muted"><?php echo $row['COUNT(problem_reports_id)']; ?></div>
        </div>
        <div class="progress" style="height: 10px;">
          <div class="progress-bar bg-blue progress-bar-striped progress-bar-animated" role="progressbar" style="width: <?php echo $row['COUNT(problem_reports_id)']; ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
      </div>
    </div>
  </div>
  <!--Problem Reports End-->

  <!--Problem Feedbacks Start-->
  <div class="col-lg-3 col-md-6 col-sm-12 mb-30">
    <div class="bg-white pd-20 box-shadow border-radius-5 height-100-p">
      <div class="project-info clearfix">
        <div class="project-info-left">
          <div class="icon box-shadow bg-light-green text-white">
            <i class="fa fa-handshake-o"></i>
          </div>
        </div>
		<?php 
			
			$stmt = $db_con->prepare("SELECT COUNT(feedback_id) FROM feedback");
			$stmt->execute();
			$row=$stmt->fetch(PDO::FETCH_ASSOC);			
		
		?>
        <div class="project-info-right">
          <span class="no text-light-green weight-500 font-24"><?php echo $row['COUNT(feedback_id)']; ?></span>
          <p class="weight-400 font-18">Feedback Reports</p>
        </div>
      </div>
	  
      <div class="project-info-progress">
        <div class="row clearfix">
          <div class="col-sm-6 text-muted weight-500">Stats</div>
          <div class="col-sm-6 text-right weight-500 font-14 text-muted"><?php echo $row['COUNT(feedback_id)']; ?></div>
        </div>
        <div class="progress" style="height: 10px;">
          <div class="progress-bar bg-light-green progress-bar-striped progress-bar-animated" role="progressbar" style="width: <?php echo $row['COUNT(feedback_id)']; ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
      </div>
    </div>
  </div>
  <!--Problem Feedbacks End-->

  <!-- Subscribers Start-->
  <div class="col-lg-3 col-md-6 col-sm-12 mb-30">
    <div class="bg-white pd-20 box-shadow border-radius-5 height-100-p">
      <div class="project-info clearfix">
        <div class="project-info-left">
          <div class="icon box-shadow bg-light-orange text-white">
            <i class="fa fa-list-alt"></i>
          </div>
        </div>
        <div class="project-info-right">
		<?php 
			
			$stmt = $db_con->prepare("SELECT COUNT(subscriber_id) FROM subscriber");
			$stmt->execute();
			$row=$stmt->fetch(PDO::FETCH_ASSOC);			
		
		?>		
          <span class="no text-light-orange weight-500 font-24"><?php echo $row['COUNT(subscriber_id)']; ?></span>
          <p class="weight-400 font-18">Subscriber Reports</p>
        </div>
      </div>
      <div class="project-info-progress">
        <div class="row clearfix">
          <div class="col-sm-6 text-muted weight-500">Stats</div>
          <div class="col-sm-6 text-right weight-500 font-14 text-muted"><?php echo $row['COUNT(subscriber_id)']; ?></div>
        </div>
        <div class="progress" style="height: 10px;">
          <div class="progress-bar bg-light-orange progress-bar-striped progress-bar-animated" role="progressbar" style="width: <?php echo $row['COUNT(subscriber_id)']; ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
      </div>
    </div>
  </div>
  <!-- Subscribers End-->

</div>

<!--Feedbacks Managed Start-->
<div class="row clearfix">
  <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 mb-30">
    <div class="bg-white pd-20 box-shadow border-radius-5 height-100-p">
      <h4 class="mb-30">Feedbacks Managed</h4>
	  
	  	<?php 
			
			$stmt = $db_con->prepare("SELECT count(status) FROM feedback Where status='Good'");
			$stmt->execute();
			$row=$stmt->fetch(PDO::FETCH_ASSOC);

			$stmt = $db_con->prepare("SELECT count(status) FROM feedback Where status='Bad'");
			$stmt->execute();
			$row1=$stmt->fetch(PDO::FETCH_ASSOC);					
		
		?>
      <div class="device-manage-progress-chart">
        <ul>
          <li class="clearfix">
            <div class="device-name">Good</div>
            <div class="device-progress">
              <div class="progress">
                <div class="progress-bar window border-radius-8" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $row['count(status)']; ?>%;">
                </div>
              </div>
            </div>
            <div class="device-total"><?php echo $row['count(status)']; ?> Good</div>
          </li>
          <li class="clearfix">
            <div class="device-name">Bad</div>
            <div class="device-progress">
              <div class="progress">
                <div class="progress-bar mac border-radius-8" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $row1['count(status)']; ?>%;">
                </div>
              </div>
            </div>
            <div class="device-total"><?php echo $row1['count(status)']; ?> </br>Bad</div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>
<!--Feedbacks Managed End-->
