<?php


	$db_host = "localhost";
	$db_name = "iexplore";
	$db_user = "root";
	$db_pass = "";
	
	try{
		
		$db_con = new PDO("mysql:host={$db_host};dbname={$db_name}",$db_user,$db_pass);
		$db_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch(PDOException $e){
		echo $e->getMessage();
	}
	
	$db_conn = mysqli_connect('localhost', 'root', '', 'iexplore');

	if(mysqli_connect_errno()){
		echo "1: Connection Failed!"; // error code # 1 connection failed 
		exit();
    }
	

?>