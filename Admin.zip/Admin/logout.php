<?php
session_start();
if(isset($_SESSION['admin_session'])) :
   unset($_SESSION['admin_session']);
   sleep(3);
   header('Location: index.php');
else :
   sleep(3);
   header('Location: index.php');
endif;
?>
