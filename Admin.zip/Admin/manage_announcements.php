<?php
include_once 'Ajax/dbconfig.php';	
session_start();

	if(!isset($_SESSION['admin_session']))
	{
		header("Location: index.php");
	}

	$stmt = $db_con->prepare("SELECT * FROM admin WHERE admin_id=:uid");
	$stmt->execute(array(":uid"=>$_SESSION['admin_session']));
	$row=$stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
	<?php include('include/head.php'); ?>
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/media/css/jquery.dataTables.css">
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<link rel="stylesheet" type="text/css" href="src/plugins/datatables/media/css/responsive.dataTables.css">
</head>
<body>

	<?php include('include/header.php'); ?>
	<?php include('include/sidebar.php'); ?>
	<div class="main-container">
		<div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>DataTable</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="manage_accounts.php">Notice</a></li>
									<li class="breadcrumb-item active" aria-current="page">Notice Information</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>



				<!--Modal Add Account Start-->
				<!-- Large modal -->
				<div class="col-md-4 col-sm-12">
					<div class="modal fade bs-example-modal-lg" id="addMember" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
						<div class="modal-dialog modal-lg modal-dialog-centered">
							<div class="modal-content">
								<div class="modal-header">
									<h4 class="modal-title" id="myLargeModalLabel"><i class="fa fa-plus"></i> Add Notice</h4>
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
								</div>
								<div class="modal-body">
									<form action="include/announcement/create.php" method="POST" id="createMemberForm">
										 <div class="col-xl-12 col-lg-8 col-md-8 col-sm-12 mb-30">
											<div class="bg-white border-radius-4 box-shadow height-100-p">
												<div class="profile-tab height-100-p">
													<div class="tab height-100-p">
														<div class="tab-content">
															<!-- Information Panel start -->
																<div class="notification-list mx-h-450 customscroll">
																	<div class="pd-20">
																		<div class="profile-timeline">
																			<div class="messages"></div>
																			<div class="timeline-month">
																				<h5><i class="fa fa-bullhorn fa-lg"></i> Notice Information:</h5>
																			</div>
																			<div class="profile-timeline-list">
																				<ul>
																					<li>
																						<div class="form-group">
																							<div class="date">Image: </div>
																							<input type="text" class="form-control form-control-lg" name="image" id="image" placeholder="Image:">
																						</div>
																					</li>
																					<li>
																						<div class="form-group">
																							<div class="date">Title: </div>
																							<input type="text" class="form-control form-control-lg" name="title" id="title" placeholder="Title:">
																						</div>
																					</li>
																					<li>
																						<div class="form-group">
																							<div class="date">Description: </div>
																							<textarea type="text" class="form-control form-control-lg" name="description" id="description" placeholder="Description:"></textarea>
																						</div>
																					</li>
																				</ul>
																			</div>
																		</div>
																	</div>
																</div>
															<!-- Information Panel End -->
														</div>
													 </div>
												 </div>
											 </div>
										 </div>
											<input type="hidden" class="form-control" id="diamonds" name="diamonds" value="0">
										<div class="modal-footer">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary">Save changes</button>
										</div>
							   </form>
								</div>
							</div>
					  </div>
					</div>
				</div>
				<!--Modal Add Account End-->

				<!--Modal Edit Account Start-->
				<!-- Large modal -->
				<div class="col-md-4 col-sm-12">
					<div class="modal fade bs-example-modal-lg" id="editMemberModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
						<div class="modal-dialog modal-lg modal-dialog-centered">
							<div class="modal-content">
								<div class="modal-header">
									<h4 class="modal-title" id="myLargeModalLabel"><i class="fa fa-pencil"></i> Edit Notice</h4>
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
								</div>
								<div class="modal-body">
									<form action="include/announcement/update.php" method="POST" id="updateMemberForm">
										 <div class="col-xl-12 col-lg-8 col-md-8 col-sm-12 mb-30">
											<div class="bg-white border-radius-4 box-shadow height-100-p">
												<div class="profile-tab height-100-p">
													<div class="tab height-100-p">
														<div class="tab-content">
															<!-- Information Panel start -->
																<div class="notification-list mx-h-450 customscroll">
																	<div class="pd-20">
																		<div class="profile-timeline">
																			<div class="edit-messages"></div>
																			<div class="timeline-month">
																				<h5><i class="fa fa-bullhorn fa-lg"></i> Edit Notice Information:</h5>
																			</div>
																			<div class="profile-timeline-list">
																				<ul>
																					<li>
																						<div class="form-group">
																							<div class="date">Image: </div>
																							<input type="file" class="form-control form-control-lg" name="editFirstname" id="editFirstname" placeholder="Image:">
																						</div>
																					</li>
																					<li>
																						<div class="form-group">
																							<div class="date">Title: </div>
																							<input type="text" class="form-control form-control-lg" name="editTitle" id="editTitle" placeholder="Title:">
																						</div>
																					</li>
																					<li>
																						<div class="form-group">
																							<div class="date">Description: </div>
																							<textarea type="text" class="form-control form-control-lg" name="editDescription" id="editDescription" placeholder="Description:"></textarea>
																						</div>
																					</li>
																				</ul>
																			</div>
																		</div>
																	</div>
																</div>
															<!-- Information Panel End -->
														</div>
													 </div>
												 </div>
											 </div>
										 </div>
										<div class="modal-footer editMemberModal">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary">Save changes</button>
										</div>
							   </form>
								</div>
							</div>
					  </div>
					</div>
				</div>
				<!--Modal Edit Account End-->


				<!--Modal View Account Start-->
				<!-- Large modal -->
				<div class="col-md-4 col-sm-12">
					<div class="modal fade bs-example-modal-lg" id="viewMemberModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
						<div class="modal-dialog modal-lg modal-dialog-centered">
							<div class="modal-content">
								<div class="modal-header">
									<h4 class="modal-title" id="myLargeModalLabel"><i class="fa fa-eye"></i> View Notice</h4>
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
								</div>
								<div class="modal-body">
							   <div class="col-xl-12 col-lg-8 col-md-8 col-sm-12 mb-30">
									<div class="bg-white border-radius-4 box-shadow height-100-p">
										<div class="profile-tab height-100-p">
											<div class="tab height-100-p">

												<div class="tab-content">
													<!-- Information Tab start -->
													<div class="tab-pane fade show active" id="timeline" role="tabpanel">
														<div class="notification-list mx-h-450 customscroll">
															<div class="pd-20">
																<div class="profile-timeline">
																	<div class="timeline-month">
																		<h5>View Notice Information:</h5>
																	</div>
																	<div class="profile-timeline-list">
																		<ul>
																			<li>
																				<div class="date">Image: </div>
																				<input type="text" class="form-control" name="viewImage" id="viewImage" readonly>
																			</li>
																			<li>
																				<div class="date">Title: </div>
																				<input type="text" class="form-control" name="viewTitle" id="viewTitle" readonly>
																			</li>
																			<li>
																				<div class="date">Date: </div>
																				<input type="text" class="form-control" name="viewDate" id="viewDate" readonly>
																			</li>
																			<li>
																				<div class="date">Description </div>
																				<textarea type="text" class="form-control" name="viewDescription" id="viewDescription" readonly></textarea>
																			</li>
																		</ul>
																	</div>
																</div>
															</div>
														</div>
													</div>
													<!-- Information Tab End -->
												</div>
											 </div>
										 </div>
									 </div>
							 	 </div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--Modal View Account End-->

				<!-- Export Datatable start -->
				<div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h5 class="text-blue">Notice Information</h5>
						</div>
						<div class="pull-right">
							<a class="btn btn-primary btn-block" href="#" data-toggle="modal" data-target="#addMember" id="addMemberModalBtn">
								<i class="fa fa-plus"></i> Add Account
							</a>
						</div>
					</div>

					<div class="row">
						<div class="removeMessages"></div>
						<table class="stripe hover multiple-select-row data-table-export nowrap" id="manageNoticeTable">
							<thead>
								<tr>
									<th class="table-plus datatable-nosort">No.</th>
									<th>Image</th>
									<th>Title</th>
									<th>Date</th>
									<th>Action</th>
								</tr>
							</thead>
								<tbody>
								</tbody>
						</table>
					</div>
				</div>
				<!-- Export Datatable End -->
			</div>
			<?php include('include/footer.php'); ?>
		</div>
	</div>
	<?php include('include/script.php'); ?>
	<script src="src/plugins/datatables/media/js/jquery.dataTables.min.js"></script>
	<script src="src/plugins/datatables/media/js/dataTables.bootstrap4.js"></script>
	<script src="src/plugins/datatables/media/js/dataTables.responsive.js"></script>
	<script src="src/plugins/datatables/media/js/responsive.bootstrap4.js"></script>
	<!-- buttons for Export datatable -->
	<script src="src/plugins/datatables/media/js/button/dataTables.buttons.js"></script>
	<script src="src/plugins/datatables/media/js/button/buttons.bootstrap4.js"></script>
	<script src="src/plugins/datatables/media/js/button/buttons.print.js"></script>
	<script src="src/plugins/datatables/media/js/button/buttons.html5.js"></script>
	<script src="src/plugins/datatables/media/js/button/buttons.flash.js"></script>
	<script src="src/plugins/datatables/media/js/button/pdfmake.min.js"></script>
	<script src="src/plugins/datatables/media/js/button/vfs_fonts.js"></script>
	<!--<script type="text/javascript" src="https://iexploresanfernando.000webhostapp.com/Admin/include/usersinformation/custom/js/index.js"></script>
-->
  <script type="text/javascript" src="include/announcement/custom/index.js"></script>

</body>
</html>
