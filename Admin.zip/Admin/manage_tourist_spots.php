<?php
include_once 'Ajax/dbconfig.php';	
session_start();

	if(!isset($_SESSION['admin_session']))
	{
		header("Location: index.php");
	}

	$stmt = $db_con->prepare("SELECT * FROM admin WHERE admin_id=:uid");
	$stmt->execute(array(":uid"=>$_SESSION['admin_session']));
	$row=$stmt->fetch(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html>
<head>
	<?php include('include/head.php'); ?>
	<!-- fancybox Popup css -->
	<link rel="stylesheet" type="text/css" href="src/plugins/fancybox/dist/jquery.fancybox.css">
</head>
<body>
	<?php include('include/header.php'); ?>
	<?php include('include/sidebar.php'); ?>
	<div class="main-container">
		<div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">
			
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-12 col-sm-12">
							<div class="title">
								<h4>Tourist Spots</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Tourist Spots</a></li>
									<li class="breadcrumb-item active" aria-current="page">Tourist Spots Information</li>
								</ol>
							</nav>
						</div>
						<div class="col-md-12 col-sm-12 text-right">
							<div class="dropdown">
								<a class="btn btn-primary" href="#" data-toggle="modal" data-target="#addMember" id="addMemberModalBtn">
									<i class="fa fa-plus"></i> Add Tourist Spots
								</a>
								<a class="btn btn-danger" href="manage_archivetourist_spots.php">
									<i class="fa fa-archive"></i> View Archive Tourist Spots
								</a>
							</div>
						</div>
					</div>
				</div><br>
	
				
				<!--Modal Add Account Start-->
				<!-- Large modal -->
				<div class="col-md-4 col-sm-12">
					<div class="modal fade bs-example-modal-lg" id="addMember" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
						<div class="modal-dialog modal-lg modal-dialog-centered">
							<div class="modal-content">
								<div class="modal-header">
									<h4 class="modal-title" id="myLargeModalLabel"><i class="fa fa-plus"></i> Add Tourist Spot</h4>
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
								</div>
								<div class="modal-body">
									<form method="POST" enctype="multipart/form-data">
										 <div class="col-xl-12 col-lg-8 col-md-8 col-sm-12 mb-30">
											<div class="bg-white border-radius-4 box-shadow height-100-p">
												<div class="profile-tab height-100-p">
													<div class="tab height-100-p">
														<div class="tab-content">
															<!-- Information Panel start -->
																<div class="notification-list mx-h-450 customscroll">
																	<div class="pd-20">
																		<div class="profile-timeline">
																			<div class="messages"></div>
																			<div class="profile-timeline-list">
																				<ul>
																					<li>
																						<div class="form-group">
																							<div class="date">Tourist Spot <br>Name: </div>
																							<input type="text" class="form-control form-control-lg" name="tourist_spot_name" id="tourist_spot_name"  placeholder="Tourist Spot Name:">
																						</div>
																					</li>
																					<li>
																						<div class="form-group">
																							<div class="date">Address: </div>
																							<input type="text" class="form-control form-control-lg" name="address" id="address"  placeholder="Address:">
																						</div>
																					</li>
																					<li>
																						<div class="form-group">
																							<div class="date">Description: </div>
																							<textarea type="text" class="form-control form-control-lg" name="description" id="description" placeholder="Description:"></textarea>
																						</div>
																					</li>
																					<li>
																						<div class="form-group">
																							<div class="date">Image: </div>
																							<input type="file" class="form-control form-control-lg" name="tourist_spot_image" id="tourist_spot_image"></textarea>
																						</div>
																					</li>
																					<input type="hidden" class="form-control form-control-lg" name="status" id="status" value="unarchive">
																				</ul>
																			</div>
																		</div>
																	</div>
																</div>
															<!-- Information Panel End -->
														</div>
													 </div>
												 </div>
											 </div>
										 </div>
										<div class="modal-footer">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="button" id="addnew" name="addnew" class="btn btn-primary">Save changes</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--Modal Add Account End-->
				
				
				
				
				
				<div class="row">
					<div id="userTable"></div>
				</div>
				
			</div>
			<?php include('include/footer.php'); ?>
		</div>
	</div>
	<?php include('include/script.php'); ?>
	<!-- fancybox Popup Js -->
	<script src="src/plugins/fancybox/dist/jquery.fancybox.js"></script>
	
	<script type = "text/javascript">
		$(document).ready(function(){
			showUser();
			//Add New
			
			
			$(document).on('click', '#addnew', function(){
				if ($('#tourist_spot_name').val()=="" || $('#address').val()=="" || $('#description').val()==""){
					alert('Please input data first');
				}
				else{
				$tourist_spot_name=$('#tourist_spot_name').val();
				$address=$('#address').val();
				$tourist_spot_image=$('#tourist_spot_image').val();
				$description=$('#description').val();
				$status=$('#status').val();
				
					$.ajax({
						type: "POST",
						url: "include/tourist_spots/addnew.php",
						data: {
							tourist_spot_name: $tourist_spot_name,
							address: $address,		
							tourist_spot_image: $tourist_spot_image,
							description: $description,
							status: $status,
							
							add: 1,
						},
						success: function(){
							showUser();
						}
					});			
				}
			});
			
			//Delete
			$(document).on('click', '.delete', function(){
				$id=$(this).val();
					$.ajax({
						type: "POST",
						url: "delete.php",
						data: {
							id: $id,
							del: 1,
						},
						success: function(){
							showUser();
						}
					});
			});
			
			//Update
			$(document).on('click', '.updateuser', function(){
				$uid=$(this).val();
				$('#edit'+$uid).modal('hide');
				
				$('body').removeClass('modal-open');
				$('.modal-backdrop').remove();
				
				$utourist_spot_name=$('#utourist_spot_name'+$uid).val();
				$uaddress=$('#uaddress'+$uid).val();
				$udescription=$('#udescription'+$uid).val();
				
					$.ajax({
						type: "POST",
						url: "include/tourist_spots/update.php",
						data: {
							id: $uid,
							tourist_spot_name: $utourist_spot_name,
							address: $uaddress,
							description: $udescription,
							edit: 1,
						},
						success: function(){
							showUser();
						}
					});
			});
			
			
			//Archive
			$(document).on('click', '.archiveuser', function(){
				$uid=$(this).val();
				$('#archive'+$uid).modal('hide');
				
				$('body').removeClass('modal-open');
				$('.modal-backdrop').remove();
				
				$ustatus=$('#ustatus'+$uid).val();
				
				$.ajax({
					type: "POST",
					url: "include/tourist_spots/archive.php",
					data: {
						id: $uid,
						status: $ustatus,
						archive: 1,
					},
					success: function(){
						showUser();
					}
				});
			});
			

		
		});
		
		//Showing our Table
		function showUser(){
			$.ajax({
				url: 'include/tourist_spots/show_unarchive.php',
				type: 'POST',
				async: false,
				data:{
					show: 1
				},
				success: function(response){
					$('#userTable').html(response);
				}
			});
		}
		
	</script>
</body>
</html>
